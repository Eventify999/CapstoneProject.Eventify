import { Component } from '@angular/core';

@Component({
  selector: 'app-vendor-dashboard',
  standalone:true,
  imports: [],
  templateUrl: './vendor-dashboard.component.html',
  styleUrl: './vendor-dashboard.component.css'
})
export class VendorDashboardComponent {

}
